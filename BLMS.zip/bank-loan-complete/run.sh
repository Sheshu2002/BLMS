#!/bin/bash
echo "Make sure MySQL 'bankloansystem' exists and root user has access."
mvn spring-boot:run

