package com.example.bank.model;
public enum ApprovalStatus { PENDING, APPROVED, REJECTED }